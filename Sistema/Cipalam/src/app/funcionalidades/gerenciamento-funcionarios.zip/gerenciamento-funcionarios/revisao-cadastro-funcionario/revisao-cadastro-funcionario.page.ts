import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-revisao-cadastro-funcionario',
  templateUrl: './revisao-cadastro-funcionario.page.html',
  styleUrls: ['./revisao-cadastro-funcionario.page.scss'],
  standalone: false
})
export class RevisaoCadastroFuncionarioPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
