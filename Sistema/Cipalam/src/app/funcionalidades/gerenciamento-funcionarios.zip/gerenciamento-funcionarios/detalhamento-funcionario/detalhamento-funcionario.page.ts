import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detalhamento-funcionario',
  templateUrl: './detalhamento-funcionario.page.html',
  styleUrls: ['./detalhamento-funcionario.page.scss'],
  standalone: false
})
export class DetalhamentoFuncionarioPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
