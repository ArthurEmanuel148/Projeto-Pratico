// src/app/funcionalidades/gerenciamento-funcionarios/gerenciamento-funcionarios.module.ts
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular'; // <-- ESSENCIAL PARA COMPONENTES IONIC
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; // <-- ESSENCIAL PARA formControlName e [disabled]
import { GerenciamentoFuncionariosRoutingModule } from './gerenciamento-funcionarios-routing.module';
import { PermissoesFuncionarioComponent } from './components/permissoes-funcionario/permissoes-funcionario.component';

@NgModule({
  declarations: [
    PermissoesFuncionarioComponent // Componente é declarado aqui
    // ... outros componentes deste módulo que não são standalone
  ],
  imports: [
    CommonModule,
    IonicModule, // Deve estar aqui para que os componentes Ionic funcionem
    FormsModule, // Adicione se usar ngModel em algum lugar
    ReactiveFormsModule, // Adicione aqui para que formGroup, formControlName funcionem
    GerenciamentoFuncionariosRoutingModule
  ]
  // Se PermissoesFuncionarioComponent for usado como um modal chamado por
  // CadastroFuncionarioPage (que está em seu próprio módulo), você não
  // necessariamente precisa exportar PermissoesFuncionarioComponent aqui,
  // a menos que outros módulos FORA de GerenciamentoFuncionariosModule o usem diretamente no template.
  // Para o ModalController, a declaração e a importação de ReactiveFormsModule e IonicModule aqui é o suficiente.
})
export class GerenciamentoFuncionariosModule { }