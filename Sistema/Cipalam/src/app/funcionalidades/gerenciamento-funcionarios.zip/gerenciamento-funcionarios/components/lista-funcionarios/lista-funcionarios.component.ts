import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lista-funcionarios',
  templateUrl: './lista-funcionarios.component.html',
  styleUrls: ['./lista-funcionarios.component.scss'],
  standalone: false
})
export class ListaFuncionariosComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
