import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ModalController } from '@ionic/angular';
import { FuncionalidadeSistema } from '../../../../core/models/funcionalidade-sistema.interface'; // Ajuste o caminho
import { FuncionalidadesSistemaService } from '../../../../core/services/funcionalidades-sistema.service'; // Ajuste o caminho

@Component({
  selector: 'app-permissoes-funcionario',
  templateUrl: './permissoes-funcionario.component.html',
  styleUrls: ['./permissoes-funcionario.component.scss'],
  standalone: false
})
export class PermissoesFuncionarioComponent implements OnInit {
  @Input() nomeFuncionario: string = '';
  // @Input() permissoesAtuais: Record<string, boolean> = {}; // Para modo de edição futuro

  permissoesForm!: FormGroup;
  todasAsFuncionalidades: FuncionalidadeSistema[] = [];

  constructor(
    private modalCtrl: ModalController,
    private fb: FormBuilder,
    private funcionalidadesService: FuncionalidadesSistemaService
  ) { }

  ngOnInit() {
    this.funcionalidadesService.getTodasFuncionalidades().subscribe(funcionalidades => {
      this.todasAsFuncionalidades = funcionalidades;
      this.criarFormularioDePermissoes();
    });
  }

  criarFormularioDePermissoes() {
    const group: { [key: string]: FormControl } = {};
    this.todasAsFuncionalidades.forEach(func => {
      // Por padrão, todas as chaves vêm ativadas (true)
      // No futuro, para edição, você usaria: this.permissoesAtuais[func.chave] || false
      group[func.chave] = this.fb.control(true);
    });
    this.permissoesForm = this.fb.group(group);
  }

  confirmarPermissoes() {
    if (this.permissoesForm.valid) {
      this.modalCtrl.dismiss(this.permissoesForm.value, 'confirmar');
    }
  }

  cancelar() {
    this.modalCtrl.dismiss(null, 'cancelar');
  }
}