package com.cipalam.cipalam_sistema.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

// definir beans, configurações, propriedades, etc.

@Configuration
public class HelloWordConfiguration {

    // @Bean
    // // @Bean é uma anotação que indica que o método deve ser tratado como um bean do Spring. Isso significa que o Spring irá gerenciar a instância retornada por este método.
    // public Transport myService() {
    //     return new car();
    // }
}
